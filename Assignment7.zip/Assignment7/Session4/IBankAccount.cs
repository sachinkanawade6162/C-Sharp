﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
    interface IBankAccount
    {
        void Deposite(double amount);
        void Withdraw(double amount);
    }
    class SavingAccount : IBankAccount
    {
        double Total_amount = 0;
        public void Deposite(double amount)
        {
            Console.WriteLine($"{amount} Deposite in your Saving Account");
            Total_amount = Total_amount + amount;
        }
        public void Withdraw(double amount)
        {
            Console.WriteLine($"{amount} Withgraw from your Saving Account");
        }
        public void Balance()
        {
            Console.WriteLine($"Your Current Balance is= {Total_amount}");
        }
    }
    class CurrentAccount:IBankAccount
    {
        double Total_amount = 0;
        public void Deposite(double amount)
        {
            Console.WriteLine($"{amount} Deposite in your Saving Account");
            Total_amount = Total_amount + amount;
        }
        public void Withdraw(double amount)
        {
            Console.WriteLine($"{amount} Withgraw from your Saving Account");
        }
        public void Balance()
        {
            Console.WriteLine($"Your Current Balance is= {Total_amount}");
        }
    }
    class Account
    {
        static void Main()
        {
            Console.WriteLine("________Saving Account__________");
            SavingAccount sa = new SavingAccount();
            Console.WriteLine("Enter the Amount");
            double amount = Convert.ToDouble(Console.ReadLine());
            sa.Deposite(amount);
            sa.Balance();
            Console.WriteLine("________Current Account__________");
            CurrentAccount ca = new CurrentAccount();
            ca.Deposite(40000.0);
            Console.WriteLine("Enter the Amount");
            double amount1 = Convert.ToDouble(Console.ReadLine());
            sa.Deposite(amount1);
            ca.Balance();
            Console.ReadLine();
        }
    }
}
