﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
    class Room
    {
        private int _number;
        private int _floor;
        private string _type;
        private int _capacity;
        private DateTime _bookedTime;
        private double _price;

        public int number
        {
            get { return _number; }
            
            set { _number = value; }
        }
        public int floor
        {
            get { return _floor; }
            set { _floor = value; }
        }
        public string type
        {
            get { return _type; }
            set { _type = value; }
        }
        public int capacity
        {
            get { return _capacity; }
            set { _capacity = value; }
        }
        public DateTime bookTime
        {
            get { return _bookedTime; }
            set { _bookedTime = value; }
        }
        public double price
        {
            get { return _price; }
            set { _price = value; }
        }
        public Room()
        {

        }
        public Room(int _number,int _floor,string _type,int _capacity,DateTime _bookedTime,double _price)
        {
            this._number = _number;
            this._number = _floor;
            this._type = _type;
            this._capacity = _capacity;
            this._bookedTime = _bookedTime;
            this._price = _price;
        }
        public override string ToString()
        {
            return $"Print Format: \nNumber:{_number} \nFloor:{_floor} \n Type:{_type} \n Capacity:{_capacity} \n Book Time:{_bookedTime} \n Price:{_price}";
        }
        static void Main()
        {
            Room r = new Room();
            Console.WriteLine("enetr the Room Number");
            int rmNo = Convert.ToInt32(Console.ReadLine());
            r.number = rmNo;
            Console.WriteLine("enetr the Floor");
            int flrNo = Convert.ToInt32(Console.ReadLine());
            r.floor = flrNo;
            Console.WriteLine("enetr the room tyep");
            string type = Console.ReadLine();
            r.type =type;
            Console.WriteLine("enetr the Capacity");
            int capacity = Convert.ToInt32(Console.ReadLine());
            r.capacity = capacity;
            Console.WriteLine("eneter the Date and Time");
            DateTime dt = Convert.ToDateTime(Console.ReadLine());
            r.bookTime = dt;
            Console.WriteLine("enetr the price");
            double price = Convert.ToDouble(Console.ReadLine());
            r.price = price;
           Console.WriteLine( r.ToString());
            Console.ReadLine();
        }

    }
}
