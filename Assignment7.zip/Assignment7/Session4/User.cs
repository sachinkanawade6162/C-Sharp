﻿using System;
using System.Collections.Generic;
namespace Session4
{
    class User
    {
        private int _id;
        private string _name;
        private string _emailId;
        private string _dateOfBirth;
        
        public User()
        {

        }
        public User(int _id,string _name,string _emailId,string _dateOfBirth)
        {
            this._id = _id;
            this._name = _name;
            this._emailId = _emailId;
            this._dateOfBirth = _dateOfBirth;     
        }
        public override string ToString()
        {
            return $"Print Format:\n Id:{_id} \n Name:{_name} \n Email Id:{_emailId} \n Date of Birth:{_dateOfBirth}";
        }

        static void Main()
        {
            Console.WriteLine("enetr the user id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enetr the user name");
            string name = Console.ReadLine();
            Console.WriteLine("eneter the email id");
            string email = Console.ReadLine();
            Console.WriteLine("enetre the date of birth");
            string dob =( Console.ReadLine());
            User u = new User(id,name,email,dob);
            Console.WriteLine(u.ToString());
            Console.ReadLine();
        }
    }
}
