﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
    class SealedClass
    {
        public void StartWriting()
        {
            Console.WriteLine("StartWriting method");
        }
        public void StopWriting()
        {
            Console.WriteLine("StopWriting method");
        }
    }
    class SealedClassDemo
    {
        static void Main()
        {
            SealedClass s = new SealedClass();
            s.StartWriting();
            s.StopWriting();
            Console.ReadLine();
        }
    }
}
