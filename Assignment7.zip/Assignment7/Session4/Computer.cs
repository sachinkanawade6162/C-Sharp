﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
   abstract class Computer
    {
        public abstract void BootUp();
        public abstract void ShutDown();
    }
    class SuperComputer:Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("This is BootUp Method Override in SuperComputer");
        }
        public override void ShutDown()
        {
            Console.WriteLine("This is ShutDown Method Override in SuperComputer");
        }
    }
    class MainfraimComputer:Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("This is BootUp Method Override in MainFraimComputer");
        }
        public override void ShutDown()
        {
            Console.WriteLine("This is ShutDown Method Override in MainFraimComputer");
        }
    }
    class MicroComputers:Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("This is BootUp Method Override in  MicroComputers");
        }
        public override void ShutDown()
        {
            Console.WriteLine("This is ShutDown Method Override in  MicroComputers");
        }
    }
    class ComputerDemo
    {
        static void Main()
        {
            Computer c = new SuperComputer();
            c.BootUp();
            c.ShutDown();
            Computer c1 = new MainfraimComputer();
            c1.BootUp();
            c1.ShutDown();
            Computer c2 = new MicroComputers();
            c2.BootUp();
            c2.ShutDown();

            Console.ReadLine();
        }
    }

}
