﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    public static class PositiveNegativeExtension
    {
        public static bool isPossitiveOrNot(this int i, int value)
        {
            if (i >= 0)
            {
                i = i + value;
                Console.WriteLine(i);
                return true;
            }
            else
            {
                Console.WriteLine("Negative");
                return false;
            }
        }
    }
    class ExtensionDemo
    {
        static void Main()
        {
            int i = -1;
            bool result = i.isPossitiveOrNot(100);
            Console.ReadLine();
        }
    }
}
