﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GST;
namespace Assignment7
{
    class GstDemo
    {
        static void Main(string[] args)
        {
            MyGst g = new MyGst();
            Console.WriteLine("enetr the Amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enetr the percentage");
            double per = Convert.ToDouble(Console.ReadLine());
            double gst;
            Console.WriteLine("total amount: {0}", g.getGst(out gst, amt, per));
            Console.WriteLine("GST :{0}", gst);
            Console.ReadLine();

        }
    }
}
